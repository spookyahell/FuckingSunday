def ps():
	print('Shit!')
	
def __init__(self):
	self.ps = ps