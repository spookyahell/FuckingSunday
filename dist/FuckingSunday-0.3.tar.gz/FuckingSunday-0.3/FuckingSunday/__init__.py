from .fuck.that import dick
from .fuck.that import shit
from .sundays.a.fun import day

def hey():
	dick.ps()

def fuck_you():
	fucking_peace_of_shit = 'Shut the fuck up you piece of shit!'
	print(fucking_peace_of_shit)