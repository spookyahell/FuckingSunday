def ps():
	print('Shit!')